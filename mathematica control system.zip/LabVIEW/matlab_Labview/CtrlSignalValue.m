function CtrlSignalValue(ctrl,val)
    CallVI('CtrlSignalValue',{'reference','variant'},{ctrl,val});
end