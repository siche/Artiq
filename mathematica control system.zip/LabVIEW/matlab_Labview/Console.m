function Console(str)
    CallVI('Console',{'print string'},{str});
end